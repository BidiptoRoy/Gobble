package com.bidiptoroy.gobble.model

data class MenuInfo (
    val id: String, val name : String,val cost_for_one : String
)
